/*
 * =====================================================================================
 *
 *       Filename:  test_proto.c
 *
 *    Description:  对google protobuf的测试
 *
 *        Version:  1.0
 *        Created:  2015年01月06日 14时33分13秒
 *       Revision:  none
 *       Compiler:  gcc
 *
 *         Author:	houbin , houbin-12@163.com
 *   Organization:  Houbin, Inc. ShangHai CN. All rights reserved.
 *
 * =====================================================================================
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <iostream>
#include <string.h>
#include <assert.h>

#include <sys/time.h>

#include "proto/lib/simple.pb.h"

typedef struct proto_pkg {
	int len;
	int id;
	int seq;
	int cmd;
	int ret;
	uint8_t data[];
} __attribute__((packed)) proto_pkg_t;

std::string rbuf;
std::string sbuf;

/* @brief 执行序列化
*/
void do_serialize()
{
	test::SceneUser user;


	test::Charbase* base = user.mutable_base();
	base->set_rolename("花木兰");
	base->set_sexy(0);
	base->set_type(1);
	base->set_level(25);
	base->set_accid(111111111);

	for (int i = 0; i < 9; ++i) 
	{
		test::Soul* soul = user.add_soul();
		soul->set_roleid(111111111111);
		soul->set_exp(10000000);
		soul->set_soulid(10000000);
		soul->set_level(13);
		soul->set_star(1);
		soul->set_equipindex(3);
		soul->set_grade(4);
	}

	for (int i = 0; i < 3; ++i) 
	{
		test::Blade* blade = user.add_blade();
		blade->set_roleid(111111111111);
		blade->set_id(10000000);
		blade->set_star(10000000);
		blade->set_quality(13);
		blade->set_strengthlv(1);
		blade->set_releaselv(2);
		blade->set_liberationnode1(4);
		for (int j = 0; j < 3; ++j) 
		{
			test::Skill* skill = blade->add_skill();
			skill->set_skillid(10000);
			skill->set_value(2324);
		}
	}
	
	user.SerializeToString(&sbuf);

	//std::cout << "序列化后大小:" << user.ByteSize() << std::endl;
}

/* @brief 执行反序列化
*/
void do_parse()
{
	rbuf = sbuf;	
	test::SceneUser user;
	user.ParseFromString(rbuf);

	std::cout << "反序列化大小" << user.ByteSize() << std::endl;
}


/* @brief 测试加密与解密的时间
*/
int main(int argc, char *argv[])
{
	srand(time(NULL));
	int i = 0;
	timeval start;
	timeval end;
	gettimeofday(&start, NULL);
	for (; i < 100000; ++i) 
	{
		do_serialize();
	}
	gettimeofday(&end, NULL);
	int total = (end.tv_sec - start.tv_sec) * 1000000 + (end.tv_usec - start.tv_usec);
	std::cout << "序列化执行100000次总花费时间: " << total << "usec;平均每次花费: " << total / 1000000.0 << "usec" << std::endl;

	gettimeofday(&start, NULL);
	for (i = 0; i < 100000; ++i) 
	{
		do_parse();
	}
	gettimeofday(&end, NULL);
	total = (end.tv_sec - start.tv_sec) * 1000000 + (end.tv_usec - start.tv_usec);
	std::cout << "反序列化执行100000次总花费时间: " << total << "usec;平均每次花费: " << total / 1000000.0 << "usec" << std::endl;


	//int len = rand() % 1000 + 1;
	//int nozip_len = (len + 1) * 4;
	////用于消息的加密与解密
	//sim.SerializeToString(&sbuf);
	//rbuf = sbuf;

	//assert(rbuf.size() == sbuf.size());

	//test::Simple tmp;	
	//tmp.ParseFromString(rbuf);


	//int zip_len = sbuf.size();

	//std::cout << "nozip_len = " << nozip_len 
	//<<"\tzip_len=" << zip_len 
	//<<"\tusedsec="  << (end.tv_sec - start.tv_sec) * 1000000 + (end.tv_usec - start.tv_usec) << "\tlen=" << tmp.id_size() 
	//<< "\t zip_rate=" << zip_len / (nozip_len * 1.0) 
	//<< std::endl;
	//sleep(1);
	//}

	//delete
	google::protobuf::ShutdownProtobufLibrary();

	return 0;
}
