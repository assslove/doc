#!/usr/bin/python
#encoding: utf-8

import sys
import struct
import time
import redis
import random

count = 1000000;
def test_hset_init(r, tmpstr):
    
    total = 0;
    cur = time.time() * 1000000;
    for i in range(0, count):
        r.hset("blade", i, tmpstr);
    last = time.time() * 1000000;
    #    print "第%u个使用%uus" % (i, (last-cur))
    total += (last - cur)

    print "hset init 总计时间为:%u us, 平均时间为:%u us" % (total, total / (count*1.0)) 

    pass

def test_hset_op(r, tmpstr):
    total = 0
    cur = time.time() * 1000000;
    for i in range(0, count):
        val = r.hget("blade", i);
    last = time.time() * 1000000;
    #    print "第%u个使用%uus" % (i, (last-cur))
    total += (last - cur)

    print "获取hget总计时间为:%u us, 平均时间为:%u us" % (total, total /  (count*1.0))

    total = 0
    cur = time.time() * 1000000;
    for i in range(0, count):
        val = r.hset("blade", i, tmpstr);
    last = time.time() * 1000000;
    #    print "第%u个使用%uus" % (i, (last-cur))
    total += (last - cur)

    print "更新hset总计时间为:%u us, 平均时间为:%u us" % (total, total / (count*1.0)) 


    pass

def test_zset_init(r):
    total = 0;
    cur = time.time() * 1000000;
    for i in range(0, count):
        r.zadd("ranking",  10000000000 + i, i);
    last = time.time() * 1000000;
#        print "第%u个使用%uus" % (i, (last-cur))
    total += (last - cur)

    print "zadd 总计时间为:%u us, 平均时间为:%u us" % (total, total /  (count*1.0))

    pass

def test_zset_op(r):
    total = 0;
    cur = time.time() * 1000000;
    for i in range(0, count):
        rank = r.zrevrank("ranking", 10000000000 + i);
    last = time.time() * 1000000;
#        print "第%u个使用%uus" % (i, (last-cur))
    total += (last - cur)

    print "zrevrank 总计时间为:%u us, 平均时间为:%u us" % (total, total /  (count*1.0))

    total = 0;
    cur = time.time() * 1000000;
    for i in range(0, count):
        r.zincrby("ranking", 10000000000 + i, i);

    last = time.time() * 1000000;
#        print "第%u个使用%uus" % (i, (last-cur))
    total += (last - cur)

    print "zincrby 总计时间为:%u us, 平均时间为:%u us" % (total, total /  (count*1.0))

    pass

def main():
    r = redis.StrictRedis(host='localhost', port=6379, db=0)
    r.flushall();

    tmpstr = "";
    for i in range(0, 300):
        tmpstr += str(random.randint(0,9));

    print "插入的字符串:", tmpstr, "长度为:", len(tmpstr), "byte";

    #init hset data 100000 300B
    print "hset key为blade 插入数据为%lu个，每长度为300B" % count
    test_hset_init(r, tmpstr);

    #test hget hset 10000次 求每次时间
    print "hset key为blade 获取和更新 %lu条数据" % count
    test_hset_op(r, tmpstr);    
    #init zset data 100000条
    test_zset_init(r);
    #test zadd arank 10000次 求每次时间 并求平均时间
    test_zset_op(r);

    pass

if __name__ == '__main__':
    main()

